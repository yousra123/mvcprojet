$(document).ready(function(){
    nbItemsInCart();
    keys();
})

function keys(){
    var typingTimer;               
    var doneTypingInterval = 1000;
    $("#searchBar").on("keyup",function(){
        clearTimeout(typingTimer);
        typingTimer = setTimeout(doneTyping,doneTypingInterval);
    }) 

    $("#searchBar").on("keydown",function(event){
        clearTimeout(typingTimer);
    })
}

function doneTyping(){
    var item = $('#searchBar').val();
    search(item);
}

//findItem.php
function search(item){
    fetch('/mvcProject/public/searchedItems',{
        method:'POST',
        body:new URLSearchParams('item=' + item)
    })
    .then(res => res.json())
    .then(res => update(res))
}

function update(res){
    //console.log(res);
    $.ajax({
        url:'/mvcProject/public/newPage',
        method:"post",
        data:{res:res},
        success:function(response){
            if(response === "not found"){
                location.reload(true);
            }else{
                $("#table").addClass("design");
                $("#table").html(response);
            }
        }
    })
}

//items.php
/*
function updatePage(res){
    if(res.length == 0){
        var output = setInfo();
        $('.barre').html(output);
        $('#table').removeClass("items");
    }else{
        $.ajax({
            url:"requests.php",
            method:"post",
            data:{res:res},
            success:function(response){
                $("#table").addClass("design space");
                $("#table").html(response);
            }
        })
    }
}*/

function setInfo(){
    $output = `<div class="alert alert-danger alert-dismissible mt-4 text-center">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <strong> Item not found .</strong>
                </div>`;
    return $output;
}

function nbItemsInCart(){
    $.ajax({
        url:'/mvcProject/public/nbItems',
        method:'get',
        data:{nbItems:'nb_items'},
        success:function(response){
            console.log(response);
            $('#nbPhones').html(response);
        }
    })
}