<?php

namespace Core\Router;

class RouterException extends \Exception{
}

?>