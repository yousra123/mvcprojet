<?php

namespace Core\Router;

use Core\Session;

class Route {

    private $name;

    private $path;

    private $controller;

    private $func;

    private $matches;

    public function __construct($name,$path,$controller,$func,$matches){
        $this->name = $name;
        $this->path = trim($path,"/");
        $this->controller = $controller;
        $this->func = $func;
        $this->matches = $matches;
    }

    public function getName(){
        return $this->name;
    }

    public function match($url){
        $url = trim($url,"/");
        $path = preg_replace('#:([\w]+)#','([0-9]+)',$this->path);
        $regex = "#^$path$#i";
    
        if(!preg_match($regex,$url,$matches)){
            return false;
        }
        $this->matches = $matches;
        return true;
    }

    public function execFunc(){
        $namespace = "Test\Controllers\\";
        $ctrl = $namespace . "Controller" . $this->controller ;
        //$instance = new $ctrl($this->controller,new Session());
        $instance = new $ctrl($this->controller,new Session());
        call_user_func_array(array($instance,$this->func),$this->matches);
    }
}
?>