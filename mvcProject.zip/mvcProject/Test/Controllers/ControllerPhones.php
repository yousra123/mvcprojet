<?php

namespace Test\Controllers;

use Core\Controller;

class ControllerPhones extends Controller{

    public function index($args){
        $data = $this->ctrlModel->getPhones();
        $results = array_chunk($data, 3);
        $this->view('viewPhones.html.twig',["results" => $results,"session" => $this->session]);
    }

    public function searchItem(){
        $item = $_POST["item"];
        $data = $this->ctrlModel->searchItem($item);
        echo json_encode($data);
    }

    public function updatePage(){
        if(isset($_POST["res"])){
            $results = $_POST["res"];
            $this->view('viewPhone.html.twig',["results" => $results,"session" => $this->session]);
        }else{
            $this->session->set("info","Item not found");
            echo "not found";
        }
    }

}     
?>