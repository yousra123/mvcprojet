$(document).ready(function(){
    $(".nbItems").change(function(){
        var qty = $(this).val();
        var row = $(this).closest("tr");
        var id = row.find(".idPhone").val();
        var price = row.find(".price").val();

        $.ajax({
            url:"/mvcProject/public/update",
            method:"post",
            data:{id:id,qty:qty,price:price},
            success:function(response){
                console.log(response);
                location.reload(true);
            }
        })
    })
})