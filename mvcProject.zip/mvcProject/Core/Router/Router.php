<?php

namespace Core\Router;

use Symfony\Component\Yaml\Yaml;
   
class Router{
    
    private $routes=[];

    private $url;

    public function __construct($url){
        $this->url = $url;
    }

    public function loadYaml($file){
        $routes = Yaml::parseFile($file);
        foreach($routes as $name => $route){
            $this->addRoute(new Route($name, $route["path"], $route["controller"],$route["func"],[]));
        }
    }

    public function addRoute(Route $route){
        $this->routes[$route->getName()] = $route;
    }

    public function getRoutes(){
        return $this->routes;
    }

    public function run(){
        foreach($this->routes as $name => $route){
            if($route->match($this->url)){
                $route->execFunc();
                return;
            }
        }
        throw new RouterException("This route doesn't exist !");
    }   
}
?>
