<?php
namespace Test\Controllers;

use Core\Controller;

class ControllerCart extends Controller{

    public function index($args){
        $results = $this->ctrlModel->getCart();
        $this->view("viewCart.html.twig",["results" => $results,"session" => $this->session]);
    }

    public function ajoutItem($args){
        $msgFlash = $this->ctrlModel->toCart($_POST["id"],$_POST["phoneName"],$_POST["phonePrice"],$_POST["phoneImage"],1);
        if($msgFlash == "success"){
            $this->session->set($msgFlash,"This item has been added successfully to the cart !");
        }else{
            $this->session->set($msgFlash,"You've already added this item to the cart !");
        }
        header("Location:/mvcProject/public/phones");
    }

    public function deleteItem($path,$id){
        $msgFlash = $this->ctrlModel->delete($id);
        $this->session->set($msgFlash,"This item has been successfully deleted from the cart !");
        header("Location:/mvcProject/public/cart");
    }

    public function updateItem(){
        $this->ctrlModel->update($_POST["id"], $_POST["qty"],$_POST["price"]);
    }

    public function fillCart(){
        echo $this->ctrlModel->nbItems();
    }

    public function clearCart(){
        $this->ctrlModel->deleteCart();
        $this->session->set("info","Cart is empty!");
        header("Location:/mvcProject/public/cart");
    }
}
?>