<?php
namespace Core;

class Session{

    public function startSession(){
        if(session_status() === PHP_SESSION_NONE){
            session_start();
        }
    }

    public function existSession(){
        $this->startSession();
        if(!empty($_SESSION)){
            $this->attrSession = $_SESSION;
            return true;
        }
        return false;
    }

    public function get($key){
        $flash = $_SESSION[$key];
        $this->delete($key);
        return $flash;
    }

    public function set($key,$value){
        $this->startSession();
        $_SESSION[$key]=$value;
    }

    public function delete($key){
        unset($_SESSION[$key]);
    }

    public function setSession($session){
        $this->attrSession = $session;
    }

}
?>