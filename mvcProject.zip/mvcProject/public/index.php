<?php

require "../vendor/autoload.php";

$router = new Core\Router\Router($_GET["url"]);
$router->loadYaml(__DIR__ . "/../config/routing.yml");
$router->run();

?>

