<?php
namespace Test\Models;

use Core\Model;

class Cart extends Model{

    public function getCart(){
        $data = $this->getItems("cart");
        return $data;
    }

    public function toCart($id,$phoneName,$phonePrice,$phoneImage,$quantity){
        $mysqli = $this->connect();
        if($stmt = $mysqli->prepare("SELECT * FROM cart WHERE id= ?")){
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $stmt->store_result(); 
            $numRows =  $stmt->num_rows;
            if($numRows == 0){
                $st = $mysqli->prepare("INSERT INTO cart VALUES (?,?,?,?,?,?)");
                $st->bind_param("isssis", $id,$phoneName,$phonePrice,$phoneImage,$quantity,$phonePrice);
                $st->execute();
                $msgFlash = "success";
            }else{
                $msgFlash = "info";
            }
        }
        return $msgFlash;
    }

    public function delete($id){
        $mysqli = $this->connect();
        $stmt = $mysqli->prepare("DELETE FROM cart WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $msgFlash = "success";
        return $msgFlash;
    }

    public function update($id,$qty,$price){
        $mysqli = $this->connect();
        $total = $qty*$price;
        $stmt = $mysqli->prepare("UPDATE cart SET totalPrice= ? , quantity=? WHERE id=?");
        $stmt->bind_param("sii",$total,$qty,$id);
        $stmt->execute();
    }

    public function nbItems(){
        $nb=$this->getNbItems("cart");
        return $nb;
    }

    public function deleteCart(){
        $this->clear("cart");
    }
}
?>