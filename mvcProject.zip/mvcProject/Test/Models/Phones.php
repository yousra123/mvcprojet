<?php

namespace Test\Models;

use Core\Model;

class Phones extends Model{
    
    public function getPhones(){
        return $this->getItems("phones");
    }

    public function searchItem($item){
        $mysqli = $this->connect();
        $result = $mysqli->query("SELECT * FROM phones WHERE phoneName LIKE '" . $item . "%'"); 
        $data=$result->fetch_all(MYSQLI_ASSOC);
        return $data;
    }

}

?>