<?php
namespace Core;

use mysqli;

class Model {
    private $dbhost;
    private $dbuser;
    private $password;    
    private $dbname;

    protected function connect(){
        $this->dbhost = "localhost";
        $this->dbuser = "root";
        $this->password = "";
        $this->dbname = "Shop";

        $connexion = new mysqli($this->dbhost,$this->dbuser,$this->password,$this->dbname);
        return $connexion;
    }

    protected function getItems($table){
        $data = [];
        $result = $this->connect()->query("SELECT * FROM " . $table);
        $row_cnt = $result->num_rows;
        if($row_cnt > 0){
            while($row = $result->fetch_assoc()){
                $data[]=$row;
            }
        }
        return $data;
    }

    protected function getNbItems($table){
        $mysqli = $this->connect();
        $result = $mysqli->query("SELECT * FROM " . $table);
        $nb = $result->num_rows;
        return $nb;
    }

    protected function clear($table){
        $mysqli = $this->connect();
        $result = $mysqli->query("DELETE FROM " . $table);
    }
}
?>