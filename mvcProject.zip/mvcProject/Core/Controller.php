<?php

    namespace Core;

    require_once "../vendor/autoload.php";
       
    class Controller{

        protected $twig;
        protected $ctrlModel;
        protected $session;
        
        public function __construct($model,Session $session){
            $this->session = $session;
            $this->ctrlModel = $this->model($model);
            $loader = new \Twig\Loader\FilesystemLoader([__DIR__.'/../Test/Views']);
            $this->twig = new \Twig\Environment($loader, array(
                'cache' => false,                             
            )); 

        }

        protected function model($model){
            $namespace = "Test\Models\\";
            $model = $namespace . $model;
            return new $model; 
        }

        protected function view($filename,$data=[]){
            $view = $this->twig->load($filename);
            $content = $view->render($data);
            echo $content;
        }

        
    }
?>